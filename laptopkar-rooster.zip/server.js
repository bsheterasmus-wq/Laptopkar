const express = require('express');
const fs = require('fs/promises');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'db.json');

// Middleware
app.use(cors());
app.use(express.json());

// Helper function to read the database
const readDB = async () => {
    try {
        const data = await fs.readFile(DB_PATH, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        // If the file doesn't exist, create it with an empty array
        if (error.code === 'ENOENT') {
            await writeDB({ reservations: [] });
            return { reservations: [] };
        }
        throw error;
    }
};

// Helper function to write to the database
const writeDB = async (data) => {
    await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
};

// API Routes

// GET all reservations
app.get('/api/reservations', async (req, res) => {
    try {
        const db = await readDB();
        res.json(db.reservations);
    } catch (error) {
        res.status(500).json({ message: 'Error reading database', error });
    }
});

// POST to sync reservations (add and delete in one transaction)
app.post('/api/reservations/sync', async (req, res) => {
    try {
        const { toAdd, toDelete } = req.body;

        if (!Array.isArray(toAdd) || !Array.isArray(toDelete)) {
            return res.status(400).json({ message: 'Invalid payload format.' });
        }

        const db = await readDB();
        
        // Filter out reservations to delete
        const toDeleteSet = new Set(toDelete);
        let updatedReservations = db.reservations.filter(r => !toDeleteSet.has(r.id));

        // Add new reservations
        updatedReservations.push(...toAdd);
        
        await writeDB({ reservations: updatedReservations });

        res.status(200).json(updatedReservations);

    } catch (error) {
        console.error('Sync Error:', error);
        res.status(500).json({ message: 'Error syncing reservations', error });
    }
});

// Serve the main HTML file for the root route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});