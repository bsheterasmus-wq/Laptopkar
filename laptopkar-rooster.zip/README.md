# Laptopkar Rooster Applicatie

Dit is een roosterapplicatie voor docenten om laptops te reserveren uit de laptopkarren van een school. De applicatie maakt gebruik van een client-server architectuur om ervoor te zorgen dat alle gebruikers dezelfde, actuele reserveringsgegevens zien.

## Architectuur

- **Frontend:** Een enkele `index.html` pagina. Deze pagina wordt naar de gebruiker gestuurd en communiceert met de backend om gegevens weer te geven en te wijzigen.
- **Backend:** Een eenvoudige `server.js` (Node.js/Express) server. Deze server beheert de API-verzoeken van de frontend.
- **Database:** Een `db.json` bestand dat fungeert als een simpele, op bestanden gebaseerde database om alle reserveringen op te slaan.

## Installatie & Opstarten

Om deze applicatie op een lokale server (bijvoorbeeld een computer binnen het schoolnetwerk) te draaien, volgt u deze stappen:

### Vereisten
- [Node.js](https://nodejs.org/) moet geïnstalleerd zijn op de servercomputer.

### Stappen

1.  **Download de bestanden:** Zorg ervoor dat alle projectbestanden (`server.js`, `package.json`, `index.html`, `db.json`, `README.md`) in dezelfde map op de servercomputer staan.

2.  **Open de terminal:** Open een terminal of command prompt in de map waar u de bestanden heeft opgeslagen.

3.  **Installeer de afhankelijkheden:** Voer het volgende commando uit. Dit downloadt en installeert de benodigde software (Express en CORS) die de server nodig heeft om te draaien.
    ```bash
    npm install
    ```

4.  **Start de server:** Voer het volgende commando uit om de server te starten.
    ```bash
    npm start
    ```

    U zou een bericht moeten zien zoals `Server is running on http://localhost:3000`. Dit betekent dat de server succesvol is gestart.

### Toegang tot de Applicatie

Zodra de server draait, kunnen docenten de applicatie gebruiken door in hun webbrowser naar het IP-adres van de servercomputer te navigeren, gevolgd door de poort `:3000`.

Bijvoorbeeld: als het IP-adres van de servercomputer `192.168.1.50` is, gaan docenten in hun browser naar:
`http://192.168.1.50:3000`

De applicatie is nu voor iedereen op het netwerk toegankelijk.